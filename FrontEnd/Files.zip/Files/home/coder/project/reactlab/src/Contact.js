export default function Contact() {
    return <h1>Contact Little Lemon on this page.</h1>
}